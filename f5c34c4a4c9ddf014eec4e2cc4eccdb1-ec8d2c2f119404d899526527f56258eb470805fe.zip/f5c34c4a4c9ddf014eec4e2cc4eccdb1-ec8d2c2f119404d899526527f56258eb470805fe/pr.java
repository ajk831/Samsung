class Ae
{
public static void main(String [] args)
{
int u=8;
float h=90;
System.out.print(u+h);
}
}